<?php include 'includes/header.php'; ?>
<div class="container my-5">
  <h1>News</h1>
  <p>Stay updated with the latest news and community announcements.</p>
  <!-- Example News Items -->
  <div class="list-group">
    <a href="#" class="list-group-item list-group-item-action">
      <h5 class="mb-1">News Item 1</h5>
      <p class="mb-1">Summary of news item 1.</p>
    </a>
    <a href="#" class="list-group-item list-group-item-action">
      <h5 class="mb-1">News Item 2</h5>
      <p class="mb-1">Summary of news item 2.</p>
    </a>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
