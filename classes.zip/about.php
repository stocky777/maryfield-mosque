<?php include 'includes/header.php'; ?>
<div class="container my-5">
  <h1>About Us</h1>
  <p>Learn about our history, mission, and community values.</p>
</div>
<?php include 'includes/footer.php'; ?>
