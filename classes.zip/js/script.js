// Custom JavaScript for the Mosque website
document.addEventListener("DOMContentLoaded", function() {
    // You can add custom interactive scripts here
    console.log("Mosque website loaded");
});
